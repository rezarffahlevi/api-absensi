<div class="card-header p-0 mb-3">
    <h4 class="card-title w-100">
        <a class="btn accordion-header btn-primary text-center" href="<?= admin_url("andalalin/docs/{$andalalin['id']}") ?>" style="font-size: 1.1rem">
            UPLOAD DOKUMEN
        </a>
    </h4>
</div>