<?php namespace App\Helpers;

class Constant
{
    public $success = '00';
    public $error = '01';
    public $error_string = '01';
    public $error_array = '02';
    public $error_auth = '03';
    public $not_found = '04';
}